class Repeller {
  constructor(x, y, width, height) {
    this.position = createVector(x, y);
    this.width = width;
    this.height = height;
  }

  display() {
    noStroke();
    fill(255, 0);
    rectMode(CENTER);
    rect(this.position.x, this.position.y, this.width, this.height);
  }
}
