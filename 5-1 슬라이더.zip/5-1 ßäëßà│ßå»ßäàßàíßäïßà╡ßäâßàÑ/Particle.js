class Particle {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.velocity = createVector(0, 0);
    this.acceleration = createVector(0, 0);
    this.size = 15;
    this.color = color(0, 50, 255, 127); // 파티클 색의 투명도를 낮춤
  }

  applyForce(force) {
    this.acceleration.add(force);
  }

  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.acceleration.mult(0);

    if (this.position.y > height) {
      this.velocity.y *= -0.33;
      this.position.y = height;
    }
  }

  display() {
    noStroke();
    fill(this.color);
    ellipse(this.position.x, this.position.y, this.size);
  }

  isOffScreen() {
    return (this.position.y > height);
  }

  checkRepellerCollision(repeller) {
    if (
      this.position.x > repeller.position.x - repeller.width / 2 &&
      this.position.x < repeller.position.x + repeller.width / 2 &&
      this.position.y > repeller.position.y - repeller.height / 2 &&
      this.position.y < repeller.position.y + repeller.height / 2
    ) {
      let repelForce = createVector(random(-5, 5), -10);
      this.applyForce(repelForce);
    }
  }

  updateWeight(newWeight) {
    this.weight = newWeight;
  }

  updateColor(newColor) {
    this.color = newColor;
  }
}