let particles = [];
let trajectoryRadius = 100;
let attractors = [];

function setup() {
  createCanvas(400, 400);

  attractors.push(new Attractor(0, 0)); // Top left corner
  attractors.push(new Attractor(width, height)); // Bottom right corner
}

function draw() {
  background(0);

  let centerX = width / 2;
  let centerY = height / 2;

  // Display attractors
  for (let i = 0; i < attractors.length; i++) {
    attractors[i].display();
  }

  // Create 30 particles at canvas center per frame
  for (let i = 0; i < 30; i++) {
    let newParticle = new Particle(centerX, centerY);
    particles.push(newParticle);
  }

  // Apply attraction and update particles
  for (let i = particles.length - 1; i >= 0; i--) {
    for (let j = 0; j < attractors.length; j++) {
      particles[i].applyAttraction(attractors[j]);
    }
    particles[i].update(createVector(centerX, centerY));
    particles[i].display();
  }
}