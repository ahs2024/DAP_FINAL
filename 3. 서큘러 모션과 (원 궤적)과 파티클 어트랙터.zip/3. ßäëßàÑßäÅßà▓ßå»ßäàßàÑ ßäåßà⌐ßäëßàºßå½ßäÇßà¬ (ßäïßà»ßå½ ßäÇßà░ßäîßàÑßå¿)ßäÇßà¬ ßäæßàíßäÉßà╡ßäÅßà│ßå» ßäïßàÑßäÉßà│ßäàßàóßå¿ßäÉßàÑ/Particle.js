class Particle {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.velocity = createVector(random(-1, 1), random(-1, 1));
    this.acceleration = createVector(0, 0); // Adding acceleration for attraction
    this.maxSpeed = 4;
  }

  applyAttraction(attraction) {
    // Calculate the direction of the force
    let force = p5.Vector.sub(attraction.position, this.position);
    let distanceSq = force.magSq();
    distanceSq = constrain(distanceSq, 1, 1000); // Limit the distance for stability
    force.setMag(2 * attraction.size / distanceSq); // Increase attraction force

    this.acceleration.add(force);
  }

  update(trajectoryCenter) {
    this.velocity.add(this.acceleration);
    this.velocity.limit(this.maxSpeed);
    this.position.add(this.velocity);

    // Check if particle is inside the trajectory
    let distance = dist(this.position.x, this.position.y, trajectoryCenter.x, trajectoryCenter.y);
    if (distance < trajectoryRadius) {
      // Calculate angle between particle and trajectory center
      let angle = atan2(this.position.y - trajectoryCenter.y, this.position.x - trajectoryCenter.x);

      // Move the particle along the trajectory
      this.position.x = trajectoryCenter.x + cos(angle) * trajectoryRadius;
      this.position.y = trajectoryCenter.y + sin(angle) * trajectoryRadius;
    }

    this.acceleration.mult(0); // Reset acceleration for next iteration
  }

  display() {
    stroke(255);
    strokeWeight(4);
    point(this.position.x, this.position.y);
  }
}
