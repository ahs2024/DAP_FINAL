class Particle {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.velocity = p5.Vector.random2D().mult(random(2, 4));
    this.acceleration = createVector();
    this.maxSpeed = 4;
    this.radius = 8;
    this.lifespan = 5000;
    this.startTime = millis();
  }

  update() {
    this.velocity.add(this.acceleration);
    this.velocity.limit(this.maxSpeed);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
  }

  display() {
    noStroke();
    fill(255, 192, 203, 50);
    ellipse(this.position.x, this.position.y, this.radius);
  }

  isDead() {
    return millis() - this.startTime > this.lifespan;
  }

  applyForce(force) {
    this.acceleration.add(force);
  }
}
