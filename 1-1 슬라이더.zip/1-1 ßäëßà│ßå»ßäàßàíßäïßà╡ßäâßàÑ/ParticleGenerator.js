class ParticleGenerator {
  constructor() {
    this.particles = [];
  }

  generateParticles() {
    for (let i = 0; i < 40; i++) {
      let newParticle = new Particle(width / 2 + random(-50, 50), height / 2 + random(-50, 50));
      this.particles.push(newParticle);
    }
  }

  updateAndDisplayParticles(attractors) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      let particle = this.particles[i];

      for (let attractor of attractors) {
        attractor.attract(particle);
      }

      particle.update();
      particle.display();

      if (particle.isDead()) {
        this.particles.splice(i, 1);
      }
    }
  }
}
