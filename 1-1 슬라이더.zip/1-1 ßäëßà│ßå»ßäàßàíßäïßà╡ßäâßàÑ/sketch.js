let attractors = [];
let particleGenerator;
let slider;
let angle = 0;
let orbitRadius = 100; // 공전 반지름

function setup() {
  createCanvas(600, 400);

  attractors.push(new Attractor(0, 0));
  attractors.push(new Attractor(0, 0));
  attractors.push(new Attractor(0, 0));
  attractors.push(new Attractor(0, 0));

  particleGenerator = new ParticleGenerator();

  slider = select('#slider');
  
  slider.input(() => {
    angle = radians(slider.value());
  });
}

function draw() {
  background(255);

  if (frameCount % 1 === 0) {
    particleGenerator.generateParticles();
  }

  particleGenerator.updateAndDisplayParticles(attractors);

  // 중심점 계산
  let centerX = width / 2;
  let centerY = height / 2;

  // 각 어트랙터의 위치 계산하여 원 공전
  for (let i = 0; i < attractors.length; i++) {
    let x = centerX + cos(angle + TWO_PI / attractors.length * i) * orbitRadius;
    let y = centerY + sin(angle + TWO_PI / attractors.length * i) * orbitRadius;
    attractors[i].position.set(x, y);
    attractors[i].display();
  }
}

  