class Attractor {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.rotation = 0;
  }

  attract(particle) {
    let force = p5.Vector.sub(this.position, particle.position);
    let distance = force.mag();
    force.setMag(2.5 / (distance ** 1));
    particle.applyForce(force);
  }

  display() {
    noStroke();
    fill(60, 60, 120, 10);
    ellipse(this.position.x, this.position.y, 200);
  }

  rotate(angle) {
    this.rotation = radians(angle);
  }
}
