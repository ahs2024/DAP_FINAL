class ParticleEmitter {
  constructor(x, y, size, col, rate) {
    this.position = createVector(x, y);
    this.size = size;
    this.col = col;
    this.rate = rate;
  }

  emit() {
    let newParticles = []; // 새로운 파티클들을 저장할 배열
    for (let i = 0; i < this.rate; i++) {
      let newParticle = new Particle(
        this.position.x + random(-5, 5),
        this.position.y + random(-5, 5),
        this.size,
        this.col
      );
      newParticles.push(newParticle); // 새로운 파티클을 배열에 추가
    }
    return newParticles; // 생성된 파티클 배열 반환
  }
}
