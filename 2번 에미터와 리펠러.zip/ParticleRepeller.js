class ParticleRepeller {
  constructor(x, y, size, col) {
    this.position = createVector(x, y);
    this.size = size;
    this.col = col;
    this.strength = -10;
  }

  repel(particle) {
    let force = p5.Vector.sub(this.position, particle.position);
    let distance = force.mag();
    distance = constrain(distance, 1, 100);
    force.normalize();
    let strength = this.strength / (distance * distance);
    force.mult(strength);
    particle.acceleration.add(force);
  }

  display() {
    noStroke();
    fill(this.col);
    ellipse(this.position.x, this.position.y, this.size * 2);
  }
}

