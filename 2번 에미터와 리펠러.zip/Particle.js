class Particle {
  constructor(x, y, size, col) {
    this.position = createVector(x, y);
    this.velocity = p5.Vector.random2D().mult(random(1, 3));
    this.acceleration = createVector();
    this.size = size;
    this.col = col;
  }

  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
  }

  display() {
    noStroke();
    fill(this.col);
    ellipse(this.position.x, this.position.y, this.size);
  }
}