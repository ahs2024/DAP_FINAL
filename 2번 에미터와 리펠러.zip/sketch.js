let particles = [];
let emitter;
let repellers = [];

function setup() {
  createCanvas(600, 400);
  emitter = new ParticleEmitter(width / 2, height / 2, 20, color(135, 206, 235, 50), 30); // 파티클 에미터 생성

  // 파티클 리펠러 생성
  for (let i = 0; i < TWO_PI; i += PI / 3) {
    let x = width / 2 + 100 * cos(i); // 거리를 1.5배로
    let y = height / 2 + 100 * sin(i); // 거리를 1.5배로
    repellers.push(new ParticleRepeller(x, y, 200, color(0, 0, 255, 0))); // 크기를 두 배로
  }
}

function draw() {
  background(255);

  // 파티클 에미터로 파티클 생성
  let newParticles = emitter.emit();
  particles = particles.concat(newParticles); // 생성된 파티클을 particles 배열에 추가

  // 파티클 리펠러에 파티클 반응
  for (let particle of particles) {
    for (let repeller of repellers) {
      repeller.repel(particle);
    }
    particle.update();
    particle.display();
  }

  // 파티클 리펠러 그리기
  for (let repeller of repellers) {
    repeller.display();
  }
}

