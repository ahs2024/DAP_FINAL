class Particle {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.velocity = p5.Vector.random2D().mult(random(2, 4));
    this.acceleration = createVector();
    this.maxSpeed = 4;
    this.radius = 8; // 파티클의 반지름
    this.lifespan = 5000; // 파티클의 수명 (5초)
    this.startTime = millis(); // 파티클이 생성된 시간
  }

  update() {
    this.velocity.add(this.acceleration);
    this.velocity.limit(this.maxSpeed);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
  }

  display() {
    noStroke();
    fill(255, 192, 203, 50); // 연한 분홍색, 오퍼시티 50
    ellipse(this.position.x, this.position.y, this.radius);
  }

  isDead() {
    return millis() - this.startTime > this.lifespan;
  }

  applyForce(force) {
    this.acceleration.add(force);
  }
}
