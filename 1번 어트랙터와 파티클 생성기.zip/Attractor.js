class Attractor {
  constructor(x, y) {
    this.position = createVector(x, y);
  }

  attract(particle) {
    let force = p5.Vector.sub(this.position, particle.position);
    let distance = force.mag();
    force.setMag(2.5 / (distance ** 1)); // 힘을 2배로 줄이고, 가동 범위는 4배로
    particle.applyForce(force);
  }

  display() {
    noStroke();
    fill(0, 255, 0, 0); // 완전히 투명한 색
    ellipse(this.position.x, this.position.y, 200); // 가동 범위 4배로
  }
}
