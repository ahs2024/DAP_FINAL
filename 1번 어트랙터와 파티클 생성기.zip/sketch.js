let attractors = [];
let particleGenerator;

function setup() {
  createCanvas(600, 400);

  // 동, 서, 남, 북에 어트렉터 생성
  attractors.push(new Attractor(width / 2 + 100, height / 2)); // 동
  attractors.push(new Attractor(width / 2 - 100, height / 2)); // 서
  attractors.push(new Attractor(width / 2, height / 2 + 100)); // 남
  attractors.push(new Attractor(width / 2, height / 2 - 100)); // 북

  particleGenerator = new ParticleGenerator();
}

function draw() {
  background(255); // 매 프레임마다 화면을 지우고 새로 그리기

  // 중심부에서 파티클 생성
  if (frameCount % 1 === 0) { // 매 1프레임마다 파티클 생성
    particleGenerator.generateParticles();
  }

  particleGenerator.updateAndDisplayParticles(attractors);

  // 어트렉터 표시 (외곽선과 색 투명하게)
  for (let attractor of attractors) {
    attractor.display();
  }
}
