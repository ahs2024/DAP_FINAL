let sketch;

function setup() {
  sketch = new Sketch();
  sketch.setup();
}

function draw() {
  sketch.draw();
}
