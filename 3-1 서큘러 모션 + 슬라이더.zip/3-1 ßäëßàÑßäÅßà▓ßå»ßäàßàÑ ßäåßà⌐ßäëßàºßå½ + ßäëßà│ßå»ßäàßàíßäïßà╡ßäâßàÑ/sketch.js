let particles = [];
let trajectoryRadius = 100;
let attractors = [];
let rSlider, gSlider, bSlider;

function setup() {
  createCanvas(400, 400);

  rSlider = createSlider(0, 255, 255);
  gSlider = createSlider(0, 255, 255);
  bSlider = createSlider(0, 255, 255);

  rSlider.position(10, 10);
  gSlider.position(10, 30);
  bSlider.position(10, 50);

  attractors.push(new Attractor(0, 0)); // Top left corner
  attractors.push(new Attractor(width, height)); // Bottom right corner
}

function draw() {
  background(0);

  let centerX = width / 2;
  let centerY = height / 2;

  // Display attractors
  for (let i = 0; i < attractors.length; i++) {
    attractors[i].display();
  }

  let r = rSlider.value();
  let g = gSlider.value();
  let b = bSlider.value();

  // Create 30 particles at canvas center per frame
  for (let i = 0; i < 10; i++) {
    let newParticle = new Particle(centerX, centerY);
    particles.push(newParticle);
  }

  // Apply attraction and update particles with color values from sliders
  for (let i = particles.length - 1; i >= 0; i--) {
    for (let j = 0; j < attractors.length; j++) {
      particles[i].applyAttraction(attractors[j]);
    }
    particles[i].update(createVector(centerX, centerY), r, g, b);
    particles[i].display();
  }
}