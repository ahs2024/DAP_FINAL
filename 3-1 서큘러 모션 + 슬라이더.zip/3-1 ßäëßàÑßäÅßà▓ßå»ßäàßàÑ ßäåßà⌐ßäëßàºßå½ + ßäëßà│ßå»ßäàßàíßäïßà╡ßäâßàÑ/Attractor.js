class Attractor {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.size = 20;
    this.opacity = 0;
  }

  display() {
    noStroke();
    fill(255, this.opacity);
    ellipse(this.position.x, this.position.y, this.size);
  }
}